package Datos;

public interface Parametros {
    String URL    = "jdbc:mysql://localhost:3306/proyectodwi";
    String DRIVER = "com.mysql.jdbc.Driver";
    String USERNAME   = "root";
    String PASSWORD  = "";
}